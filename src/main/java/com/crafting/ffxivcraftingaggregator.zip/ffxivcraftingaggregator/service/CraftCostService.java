package com.crafting.ffxivcraftingaggregator.service;

import com.crafting.ffxivcraftingaggregator.domain.dto.CraftCostNode;

public interface CraftCostService {

    /**
     * Works out whether the given item is cheaper to buy or to craft, recursing through every
     * craftable ingredient and making the same decision at each level.
     *
     * @param itemXivapiId the item to price
     * @param quantity     how many are wanted; affects craft counts through recipe yield
     * @param scope        canonical world or data centre name, already validated by WorldRegistry
     */
    CraftCostNode calculate(int itemXivapiId, int quantity, String scope);
}