package com.crafting.ffxivcraftingaggregator.service.impl;

import com.crafting.ffxivcraftingaggregator.domain.dto.CachedPrice;
import com.crafting.ffxivcraftingaggregator.domain.dto.CraftCostNode;
import com.crafting.ffxivcraftingaggregator.domain.dto.CraftCostNode.Decision;
import com.crafting.ffxivcraftingaggregator.domain.entity.Item;
import com.crafting.ffxivcraftingaggregator.domain.entity.Recipe;
import com.crafting.ffxivcraftingaggregator.domain.entity.RecipeMaterials;
import com.crafting.ffxivcraftingaggregator.exception.ItemNotFoundException;
import com.crafting.ffxivcraftingaggregator.repository.ItemRepository;
import com.crafting.ffxivcraftingaggregator.repository.RecipeRepository;
import com.crafting.ffxivcraftingaggregator.service.CraftCostService;
import com.crafting.ffxivcraftingaggregator.service.MarketPriceService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class CraftCostServiceImpl implements CraftCostService {

    private static final Logger log = LoggerFactory.getLogger(CraftCostServiceImpl.class);

    /**
     * Hard ceiling on how deep the ingredient tree is walked. FFXIV recipes nest perhaps five
     * levels, so this is generous - it exists so that malformed third-party data cannot produce
     * unbounded work, not because legitimate recipes approach it.
     */
    private static final int MAX_DEPTH = 12;

    private final ItemRepository itemRepository;
    private final RecipeRepository recipeRepository;
    private final MarketPriceService marketPriceService;

    public CraftCostServiceImpl(ItemRepository itemRepository,
                                RecipeRepository recipeRepository,
                                MarketPriceService marketPriceService) {
        this.itemRepository = itemRepository;
        this.recipeRepository = recipeRepository;
        this.marketPriceService = marketPriceService;
    }

    @Override
    @Transactional(readOnly = true)
    public CraftCostNode calculate(int itemXivapiId, int quantity, String scope) {

        if (quantity < 1) {
            throw new IllegalArgumentException("Quantity must be at least 1");
        }

        Item root = itemRepository.findByXivapiId(itemXivapiId)
                .orElseThrow(() -> new ItemNotFoundException("No item with id " + itemXivapiId));

        // Phase 1: pull the whole recipe tree into memory, one query per level.
        RecipeTree tree = loadTree(itemXivapiId, root.getName());

        // Phase 2: one price lookup for every item in the tree. Doing this before the walk rather
        // than during it is the difference between one round trip and one per ingredient - the
        // same N+1 problem as in the data layer, but over the network where it costs far more.
        Map<Integer, CachedPrice> prices =
                marketPriceService.getPrices(List.copyOf(tree.itemNames().keySet()), scope);

        // Phase 3: recurse over in-memory data only. No I/O, so depth is cheap.
        return compute(itemXivapiId, quantity, tree, prices, new ArrayDeque<>());
    }

    // ------------------------------------------------------------------
    // Phase 1 - level order tree load
    // ------------------------------------------------------------------

    /**
     * Loads every recipe reachable from the root, breadth first.
     *
     * <p>One query per LEVEL rather than per node. Walking the tree node by node and letting JPA
     * lazy-load each ingredient list would issue a query per item; a wide tree with 60 distinct
     * materials would mean 60 round trips. Levels collapse that to roughly the depth of the tree.
     *
     * <p>Entities are flattened into plain records here, inside the transaction, so nothing later
     * touches a lazy collection outside its session.
     */
    private RecipeTree loadTree(int rootItemId, String rootItemName) {

        Map<Integer, RecipeNode> recipesByResultItem = new HashMap<>();
        Map<Integer, String> itemNames = new HashMap<>();
        itemNames.put(rootItemId, rootItemName);

        Set<Integer> alreadyQueried = new HashSet<>();
        Set<Integer> frontier = new HashSet<>();
        frontier.add(rootItemId);

        int depth = 0;

        while (!frontier.isEmpty() && depth < MAX_DEPTH) {

            List<Recipe> recipes = recipeRepository.findByResultItemXivapiIdInWithIngredients(frontier);
            alreadyQueried.addAll(frontier);

            Set<Integer> nextFrontier = new HashSet<>();

            for (Recipe recipe : recipes) {
                int resultItemId = recipe.getResultItem().getXivapiId();

                // An item can have more than one recipe - different jobs, or expert variants.
                // The first is kept for determinism. Costing every alternative and taking the
                // cheapest would be more correct and is a natural follow-up.
                if (recipesByResultItem.containsKey(resultItemId)) {
                    continue;
                }

                List<Ingredient> ingredients = new ArrayList<>();

                for (RecipeMaterials ri : recipe.getRecipeIngredients()) {
                    int ingredientItemId = ri.getItem().getXivapiId();

                    ingredients.add(new Ingredient(ingredientItemId, ri.getQuantity()));
                    itemNames.put(ingredientItemId, ri.getItem().getName());

                    // Only descend into ingredients that are themselves craftable, and only once.
                    // The alreadyQueried check is what keeps a diamond-shaped tree - the same
                    // base material feeding several branches - from being queried repeatedly.
                    if (ri.getItem().isCanBeCrafted() && !alreadyQueried.contains(ingredientItemId)) {
                        nextFrontier.add(ingredientItemId);
                    }
                }

                recipesByResultItem.put(resultItemId,
                        new RecipeNode(resultItemId, recipe.getResultQuantity(), ingredients));
            }

            frontier = nextFrontier;
            depth++;
        }

        if (depth >= MAX_DEPTH && !frontier.isEmpty()) {
            log.warn("Recipe tree for item {} hit the depth limit of {}; results may be incomplete",
                    rootItemId, MAX_DEPTH);
        }

        log.debug("Loaded recipe tree for item {}: {} recipes, {} distinct items, depth {}",
                rootItemId, recipesByResultItem.size(), itemNames.size(), depth);

        return new RecipeTree(recipesByResultItem, itemNames);
    }

    // ------------------------------------------------------------------
    // Phase 3 - recursive costing
    // ------------------------------------------------------------------

    /**
     * Costs one item and, if it is craftable, every ingredient beneath it.
     *
     * @param path items currently being expanded, used to detect a recipe cycle. An item is pushed
     *             on entry and popped on exit, so the SAME item appearing in two sibling branches
     *             is fine - only a genuine loop back up the current path is rejected.
     */
    private CraftCostNode compute(int itemXivapiId,
                                  int quantityNeeded,
                                  RecipeTree tree,
                                  Map<Integer, CachedPrice> prices,
                                  Deque<Integer> path) {

        String itemName = tree.itemNames().getOrDefault(itemXivapiId, "Unknown item");

        if (path.contains(itemXivapiId)) {
            log.warn("Recipe cycle detected at item {} ({})", itemXivapiId, itemName);
            return CraftCostNode.builder()
                    .itemXivapiId(itemXivapiId)
                    .itemName(itemName)
                    .quantityNeeded(quantityNeeded)
                    .decision(Decision.CYCLE)
                    .build();
        }

        // --- buy side -------------------------------------------------
        CachedPrice price = prices.get(itemXivapiId);

        Long buyCost = null;
        Integer cheapestWorldId = null;

        if (price != null && price.isBuyable()) {
            buyCost = price.minPrice() * quantityNeeded;
            cheapestWorldId = price.cheapestWorldId();
        }

        // --- craft side -----------------------------------------------
        RecipeNode recipe = tree.recipesByResultItem().get(itemXivapiId);

        Long craftCost = null;
        List<CraftCostNode> children = new ArrayList<>();
        int craftsRequired = 0;
        int surplus = 0;

        if (recipe != null) {
            path.push(itemXivapiId);

            // Recipes yield resultQuantity per craft, so wanting 5 of something made 3 at a time
            // means running it twice and having 1 spare. Rounding down here would understate the
            // cost of every multi-yield recipe in the tree.
            craftsRequired = Math.ceilDiv(quantityNeeded, recipe.resultQuantity());
            surplus = (craftsRequired * recipe.resultQuantity()) - quantityNeeded;

            long ingredientTotal = 0;
            boolean allIngredientsObtainable = true;

            for (Ingredient ingredient : recipe.ingredients()) {
                CraftCostNode child = compute(
                        ingredient.itemXivapiId(),
                        ingredient.quantity() * craftsRequired,
                        tree, prices, path);

                children.add(child);

                if (child.effectiveCost() == null) {
                    // One unobtainable ingredient makes the whole craft cost unknown. Skipping it
                    // and summing the rest would report a cheaper craft than is actually possible.
                    allIngredientsObtainable = false;
                } else {
                    ingredientTotal += child.effectiveCost();
                }
            }

            path.pop();

            if (allIngredientsObtainable) {
                craftCost = ingredientTotal;
            }
        }

        // --- the decision ---------------------------------------------
        Long effectiveCost;
        Decision decision;

        if (buyCost == null && craftCost == null) {
            effectiveCost = null;
            decision = Decision.UNOBTAINABLE;
        } else if (craftCost == null) {
            effectiveCost = buyCost;
            decision = Decision.BUY;
        } else if (buyCost == null || craftCost < buyCost) {
            effectiveCost = craftCost;
            decision = Decision.CRAFT;
        } else {
            // Ties go to buying: same gil, no crafting time, no materials tied up.
            effectiveCost = buyCost;
            decision = Decision.BUY;
        }

        return CraftCostNode.builder()
                .itemXivapiId(itemXivapiId)
                .itemName(itemName)
                .quantityNeeded(quantityNeeded)
                .buyCost(buyCost)
                .craftCost(craftCost)
                .effectiveCost(effectiveCost)
                .decision(decision)
                .craftsRequired(craftsRequired)
                .surplus(surplus)
                .cheapestWorldId(cheapestWorldId)
                .ingredients(children)
                .build();
    }

    // ------------------------------------------------------------------
    // In-memory view of the tree, detached from JPA
    // ------------------------------------------------------------------

    private record RecipeTree(Map<Integer, RecipeNode> recipesByResultItem,
                              Map<Integer, String> itemNames) {
    }

    private record RecipeNode(int resultItemXivapiId,
                              int resultQuantity,
                              List<Ingredient> ingredients) {
    }

    private record Ingredient(int itemXivapiId, int quantity) {
    }
}