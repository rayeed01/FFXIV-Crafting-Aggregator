package com.crafting.ffxivcraftingaggregator.domain.dto;

import lombok.Builder;

import java.util.List;

/**
 * One node of the buy-vs-craft tree.
 *
 * <p>Every node answers the same question independently: is it cheaper to buy this item, or to
 * craft it from its ingredients? The answer is not uniform down the tree - an item three levels
 * deep can be cheaper to buy even when its parent is cheaper to craft, which is exactly the
 * comparison a crafter cannot easily do by hand.
 *
 * <p>Costs are for {@code quantityNeeded} units, not per unit, so they can be summed directly by
 * the parent.
 */
@Builder
public record CraftCostNode(int itemXivapiId,
                            String itemName,
                            int quantityNeeded,
                            Long buyCost,
                            Long craftCost,
                            Long effectiveCost,
                            Decision decision,
                            int craftsRequired,
                            int surplus,
                            Integer cheapestWorldId,
                            List<CraftCostNode> ingredients) {

    /**
     * Lombok's builder leaves an unset list null, so it is normalised here rather than at every
     * call site. Also makes the list immutable, which matters because these nodes are shared
     * across a tree and handed straight out to a controller.
     */
    public CraftCostNode {
        ingredients = (ingredients == null) ? List.of() : List.copyOf(ingredients);
    }

    public enum Decision { BUY, CRAFT, UNOBTAINABLE, CYCLE }

    public boolean isObtainable() {
        return effectiveCost != null;
    }
}
