package com.crafting.ffxivcraftingaggregator.domain.dto;

import jakarta.validation.constraints.Size;
import lombok.Builder;
import lombok.NonNull;

import java.util.UUID;

@Builder
public record SavedCraftRecipeRequest(@NonNull
                                      UUID recipeId,

                                      @Size(min = 1, max = 999, message = "Quantity must be between {min} and {mex}")
                                      int quantity) {
}
