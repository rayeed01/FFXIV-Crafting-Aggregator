package com.crafting.ffxivcraftingaggregator.controller;

import com.crafting.ffxivcraftingaggregator.domain.dto.CraftCostNode;
import com.crafting.ffxivcraftingaggregator.service.CraftCostService;
import com.crafting.ffxivcraftingaggregator.service.WorldRegistry;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/craft-cost")
@Validated
public class CraftCostController {

    private final CraftCostService craftCostService;
    private final WorldRegistry worldRegistry;

    public CraftCostController(CraftCostService craftCostService,
                               WorldRegistry worldRegistry) {
        this.craftCostService = craftCostService;
        this.worldRegistry = worldRegistry;
    }

    /**
     * GET /api/v1/craft-cost/{itemXivapiId}?quantity=5&scope=Aether
     *
     * <p>Returns the full ingredient tree with a buy-or-craft decision at every level.
     *
     * <p>An upper bound on quantity is enforced because quantity drives craftsRequired, which
     * multiplies ingredient quantities the whole way down the tree. It does not change how much
     * work the server does, but an absurd figure produces an answer nobody asked a real question
     * about, and gil totals that risk overflowing.
     */
    @GetMapping("/{itemXivapiId}")
    public ResponseEntity<CraftCostNode> calculate(
            @PathVariable int itemXivapiId,
            @RequestParam(defaultValue = "1") @Min(1) @Max(9999) int quantity,
            @RequestParam @NotBlank String scope) {

        // Normalised before it reaches the service so that "aether" and "Aether" hit the same
        // Redis keys rather than creating parallel cache namespaces for the same data.
        String canonicalScope = resolveScope(scope);

        return ResponseEntity.ok(craftCostService.calculate(itemXivapiId, quantity, canonicalScope));
    }

    /**
     * Universalis accepts either a world or a data centre in the same position, so both are tried.
     * A world lookup failing is not an error - it usually just means a data centre was supplied.
     * If neither matches, the data centre exception propagates and becomes a 400.
     *
     * <p>Using exceptions for control flow here is not lovely. If a third caller needs this, the
     * right move is a canonicalScopeName method on WorldRegistry rather than a fourth copy.
     */
    private String resolveScope(String scope) {
        try {
            return worldRegistry.canonicalWorldName(scope);
        } catch (RuntimeException ex) {
            return worldRegistry.canonicalDataCenterName(scope);
        }
    }
}